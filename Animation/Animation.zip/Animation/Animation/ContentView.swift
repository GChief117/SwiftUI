//
//  ContentView.swift
//  Animation
//
//  Created by Gunnar Beck on 12/4/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
            LogoView()
        }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

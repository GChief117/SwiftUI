//
//  AnimationApp.swift
//  Animation
//
//  Created by Gunnar Beck on 12/4/22.
//

import SwiftUI

@main
struct AnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
